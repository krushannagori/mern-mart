import React from 'react'
import Signup from './Components/Signup'

const App = () => {
  return (
    <div>
      <Signup/>
    </div>
  )
}

export default App