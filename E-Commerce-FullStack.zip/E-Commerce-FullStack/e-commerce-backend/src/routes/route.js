const router = require("express").Router();
const authMiddleware = require("../middleware/auth");
const {
  signUpUser,
  loginUser,
  getUsers,
  getUserById,
  updateUser,
  deleteUser,
} = require("../controllers/userController");
const {
  addProduct,
  getProducts,
  getProductById,
  updateProduct,
  deleteProduct,
} = require("../controllers/productController");

const {
  addToCart,
  getAllCarts,
  getCart,
  removeCart,
} = require("../controllers/cartController");

// Users
router.post("/signupUser", signUpUser);
router.post("/loginUser", loginUser);
router.get("/getUsers", authMiddleware, getUsers);
router.get("/getUser/:userId", authMiddleware, getUserById);
router.put("/updateUser/:userId", authMiddleware, updateUser);
router.delete("/deleteUser/:userId", authMiddleware, deleteUser);

// Products
router.post("/addProduct", authMiddleware, addProduct);
router.get("/getProducts", authMiddleware, getProducts);
router.get("/getProduct/:productId", authMiddleware, getProductById);
router.put("/updateProduct/:productId", authMiddleware, updateProduct);
router.delete("/deleteProduct/:productId", authMiddleware, deleteProduct);

// Cart
router.post("/addToCart", authMiddleware, addToCart);
router.get("/getAllCarts", authMiddleware, getAllCarts);
router.get("/getCart/:userId", getCart);
router.delete("/removeProductFromCart", removeCart);
module.exports = router;
