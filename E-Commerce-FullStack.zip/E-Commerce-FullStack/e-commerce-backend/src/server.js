const express = require("express");
const mongoose = require("mongoose");
const myRoutes = require("./routes/route");
const cors = require("cors");

const app = express();

app.use(cors());

app.use(express.json());
app.use("/", myRoutes);

mongoose
  .connect(
    "mongodb+srv://Sumit001:Sumit%40001@cluster0.oev5m.mongodb.net/ECommerce-FullStack"
  )
  .then(() => console.log("DB Connected Successfully"))
  .catch((err) => console.log("DB Not Connected", err));

app.get("/test", (req, res) => {
  res.send("Hello");
});

app.listen(3500, (err) => {
  err ? console.log(err) : console.log("Server is Running at port 3500");
});
