const productModel = require("../models/productModel");
const { isValid } = require("./validator");
const mongoose = require("mongoose");

const addProduct = async (req, res) => {
  try {
    let productData = req.body;
    if (Object.keys(productData).length === 0) {
      return res.status(400).json({ msg: "Bad Request, No Data Provided" });
    }

    let {
      pImage,
      title,
      description,
      price,
      stock,
      ratings,
      isFreeShipping,
      isDeleted,
      deletedAt,
    } = productData;

    // Product Image Validation
    if (!isValid(pImage)) {
      return res.status(400).json({ msg: "Product Image is Required" });
    }

    // Product Title Validation
    if (!isValid(title)) {
      return res.status(400).json({ msg: "Product Title is Required" });
    }

    const checkDuplicateProductTitle = await productModel.findOne({ title });
    if (checkDuplicateProductTitle) {
      return res.status(400).json({ msg: "Product Already Exists" });
    }

    // Product Description Validation
    if (!isValid(description)) {
      return res.status(400).json({ msg: "Product Description is Required" });
    }

    // Product Price Validation
    if (!isValid(price)) {
      return res.status(400).json({ msg: "Product Price is Required" });
    }

    if (typeof price !== "number") {
      return res.status(400).json({ msg: "Invalid Price" });
    }

    // Product Stock Validation
    if (!isValid(stock) || typeof stock !== "number" || stock < 0) {
      return res.status(400).json({ msg: "Valid Stock Quantity is Required" });
    }

    // Product Rating Validation
    if (typeof ratings !== "number" || ratings < 0 || ratings > 5) {
      return res.status(400).json({ msg: "Invalid Rating" });
    }

    // Free Shipping Validation
    if (
      typeof isFreeShipping !== "undefined" &&
      typeof isFreeShipping !== "boolean"
    ) {
      return res
        .status(400)
        .json({ msg: "isFreeShipping must be a boolean value" });
    }

    // is Deleted Validation
    if (typeof isDeleted !== "undefined" && typeof isDeleted !== "boolean") {
      return res.status(400).json({ msg: "isDeleted must be a boolean value" });
    }

    // deleted At
    if (isDeleted && deletedAt && isNaN(Date.parse(deletedAt))) {
      return res.status(400).json({ msg: "deleted At must be a date format" });
    }

    let newProducts = {
      pImage,
      title,
      description,
      price,
      stock,
      ratings,
      isFreeShipping: isFreeShipping || false,
      isDeleted: isDeleted || false,
      deletedAt: isDeleted ? new Date() : null,
    };

    let products = await productModel.create(newProducts);
    return res
      .status(201)
      .json({ msg: "Product Added Successfully", products });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ msg: "Internal Server error" });
  }
};

const getProducts = async (req, res) => {
  try {
    let products = await productModel.find(
      { isDeleted: false },
      { _id: 0, __v: 0, isDeleted: 0, deletedAt: 0, createdAt: 0, updatedAt: 0 }
    );
    if (!products.length) {
      return res.status(404).json({ msg: "No Product Found" });
    }
    return res.status(200).json({ products });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ msg: "Internal Server error" });
  }
};

const getProductById = async (req, res) => {
  try {
    let productId = req.params.productId;
    if (!mongoose.isValidObjectId(productId)) {
      return res.status(400).json({ msg: "Invalid Product Id" });
    }

    let product = await productModel
      .findById(productId, { isDeleted: false })
      .select("-__v");

    if (!product) {
      return res.status(404).json({ msg: "No Product Found" });
    }
    return res.status(200).json({ product });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ msg: "Internal Server error" });
  }
};

const updateProduct = async (req, res) => {
  try {
    let productData = req.body;
    if (Object.keys(productData).length === 0) {
      return res.status(400).json({ msg: "No Data To Update" });
    }

    let productId = req.params.productId;
    if (!mongoose.isValidObjectId(productId)) {
      return res.status(400).json({ msg: "Invalid Product Id" });
    }

    let { pImage, title, description, price, stock, ratings, isFreeShipping } =
      productData;

    // Product Image Validation

    if (pImage && !isValid(pImage)) {
      return res.status(400).json({ msg: "Product Image is required" });
    }

    // Product Title Validation
    if (title) {
      if (!isValid(title)) {
        return res.status(400).json({ msg: "Product Title is Required" });
      }

      const checkDuplicateProductTitle = await productModel.findOne({
        title,
      });
      if (checkDuplicateProductTitle) {
        return res.status(400).json({ msg: "Product Already Exists" });
      }
    }

    // Product Description Validation
    if (description) {
      if (!isValid(description)) {
        return res.status(400).json({ msg: "Product Description is Required" });
      }
    }

    // Product Price Validation
    if (price) {
      if (!isValid(price)) {
        return res.status(400).json({ msg: "Product Price is Required" });
      }

      if (typeof price !== "number") {
        return res.status(400).json({ msg: "Invalid Price" });
      }
    }

    // Product Stock Validation
    if (stock) {
      if (!isValid(stock) || typeof stock !== "number" || stock < 0) {
        return res
          .status(400)
          .json({ msg: "Valid Stock Quantity is Required" });
      }
    }

    // Product Rating Validation
    if (ratings) {
      if (typeof ratings !== "number" || ratings < 0 || ratings > 5) {
        return res.status(400).json({ msg: "Invalid Rating" });
      }
    }

    // Free Shipping Validation
    if (isFreeShipping) {
      if (
        typeof isFreeShipping !== "undefined" &&
        typeof isFreeShipping !== "boolean"
      ) {
        return res
          .status(400)
          .json({ msg: "isFreeShipping must be a boolean value" });
      }
    }

    const updatedProduct = await productModel.findByIdAndUpdate(
      productId,
      productData,
      {
        new: true,
      }
    );

    if (!updatedProduct) {
      return res.status(404).json({ msg: "product Not Found" });
    }

    return res
      .status(200)
      .json({ msg: "User Data Updated Successfully", updatedProduct });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ msg: "Internal Server error" });
  }
};

const deleteProduct = async (req, res) => {
  try {
    let productId = req.params.productId;
    if (!mongoose.isValidObjectId(productId)) {
      return res.status(400).json({ msg: "Invalid Product Id" });
    }

    let deletedProduct = await productModel.findByIdAndDelete(productId, {
      isDeleted: false,
    });

    if (!deletedProduct) {
      return res.status(404).json({ msg: "Product Not Found" });
    }

    return res.status(200).json({ msg: `${deletedProduct.title} is deleted` });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ msg: "Internal Server Error", error });
  }
};

module.exports = {
  addProduct,
  getProducts,
  getProductById,
  updateProduct,
  deleteProduct,
};
